#include <iostream>
#include <locale.h>

using namespace std;

struct kumas
{
    string ipliktipi;
    int dm2agirlik;
    string dokumatipi;
    string renk;
    int miktar;
};

struct iskelet
{
    string malzeme;
    string tarz;
    string birlestirme;
    int boyut;
    int miktar;
};

struct mobilya
{
    kumas kaplama;
    iskelet malzeme;
    int fiyat;
    int adet;
};

int main()
{
    setlocale(LC_ALL, "Turkish");
    
    mobilya esya[10];
    int topla = 0;

    for (int i = 0;i < 10;i++)
    {
        cout << "-----------------------------------------------" << endl;
        cout << "-----------------------------------------------" << endl;

        cout <<i+1<< ". Mobilyan�n kuma� malzemesini giriniz : ";
        cin >> esya[i].malzeme.malzeme;
        cout << i+1 << ". Mobilyan�n kuma� tarz�n� giriniz ; ";
        cin >> esya[i].malzeme.tarz;
        cout << i+1 << ". Mobilyan�n kuma� birlesme seklini giriniz : ";
        cin >> esya[i].malzeme.birlestirme;
        cout << i+1 << ". Mobilyan�n kuma� boyutunu giriniz : " ;
        cin >> esya[i].malzeme.boyut;
        cout << i+1 << ". Mobilyan�n kuma� miktar�n� giriniz : ";
        cin >> esya[i].malzeme.miktar;


        cout <<i+1 <<". Mobilyan�n iplik tipini giriniz : ";
        cin >> esya[i].kaplama.ipliktipi;
        cout << i+1 << ". Mobilyan�n dm2 ag�rl���n� giriniz : ";
        cin >> esya[i].kaplama.dm2agirlik;
        cout << i+1 << ". Mobilyan�n dokumatipini giriniz : ";
        cin >> esya[i].kaplama.dokumatipi;
        cout << i+1 << ". Mobilyan�n rengini giriniz : ";
        cin >> esya[i].kaplama.renk;
        cout << i+1 << ". Mobilyan�n miktar�n� giriniz : ";
        cin >> esya[i].kaplama.miktar;
        
        cout << i + 1 << ". Mobilyan�n fiyat�n� giriniz : ";
        cin >> esya[i].fiyat;
        cout << i + 1 << ". Mobilyan�n adetini giriniz : ";
        cin >> esya[i].adet;

        cout << "-----------------------------------------------" << endl;
        cout << "-----------------------------------------------" << endl;
    }

    for (int i = 0;i < 10;i++)
    {
        cout << "-----------------------------------------------" << endl;
        cout << "-----------------------------------------------" << endl;
        
        cout << i + 1 << ". Mobilyan�n malzemesi :"<< esya[i].malzeme.malzeme<<endl;

        cout << i + 1 << ". Mobilyan�n kuma� tarz� :"<< esya[i].malzeme.tarz<<endl;
        cout << i + 1 << ". Mobilyan�n kuma� birlesme sekli :"<< esya[i].malzeme.birlestirme<<endl;
        cout << i + 1 << ". Mobilyan�n kuma� boyutu :"<< esya[i].malzeme.boyut<<endl;
        cout << i + 1 << ". Mobilyan�n kuma� miktar� :"<< esya[i].malzeme.miktar<<endl;

        cout << i + 1 << ". Mobilyan�n iplik tipi :"<< esya[i].kaplama.ipliktipi<<endl;
        cout << i + 1 << ". Mobilyan�n dm2 ag�rl��� :"<< esya[i].kaplama.dm2agirlik<<endl;
        cout << i + 1 << ". Mobilyan�n dokuma tipi :"<< esya[i].kaplama.dokumatipi<<endl;
        cout << i + 1 << ". Mobilyan�n rengi :"<< esya[i].kaplama.renk<<endl;
        cout << i + 1 << ". Mobilyan�n miktar� :"<< esya[i].kaplama.miktar<<endl;

        cout << i + 1 << ". Mobilyan�n fiyat� : "<< esya[i].fiyat<<endl;
        cout << i + 1 << ". Mobilyan�n adeti : "<< esya[i].adet<<endl;

        topla += esya[i].fiyat*esya[i].adet ;
        cout << "-----------------------------------------------" << endl;
        cout << "-----------------------------------------------" << endl;
    }
    
    cout << "Mobilyalar�n toplam fiyat� : " << topla << endl;

    return 0;
}
