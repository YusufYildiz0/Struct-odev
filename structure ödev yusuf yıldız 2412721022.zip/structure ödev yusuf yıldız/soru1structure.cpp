#include <iostream>
#include <locale.h>

using namespace std;

enum Yakit
{
    Benzin, Dizel, Lpg, Hibrit,
};

struct otomobil
{
    string marka;
    int yil;
    string model;
    Yakit yakit;
    int km;
    int fiyat;
};

int main()
{
    setlocale(LC_ALL, "Turkish");
    otomobil binek, suv, ticari;
	
	int a=binek.yakit,b=suv.yakit,c=ticari.yakit;
	
	cout<<"Binek arac�n�n markas�n� giriniz :";
	cin>>binek.marka;
	cout<<"Binek arac�n�n modelini giriniz :";
    cin>>binek.model;
    cout<<"Binek arac�n�n �retim y�l�n� giriniz :";
    cin>>binek.yil;
    cout<<"Binek arac�n�n yak�t t�r�n� giriniz (Benzin=0 Dizel=1 Lpg=2 Hibrit=3) :";
    cin>>a;
    cout<<"Binek arac�n�n kilometresini giriniz :";
    cin>>binek.km;
    cout<<"Binek arac�n�n fiyat�n� giriniz :";
    cin>>binek.fiyat;
	
	cout << "------------------------------------------------" << endl;
    cout << "------------------------------------------------" << endl;
    
    cout << binek.marka << " " << binek.model <<" Arac�n�n �zellikleri:"<<endl;
    cout << "�retim tarihi : " << binek.yil<<endl<<"Kilometresi : "<<binek.km<<endl<<"Yak�t t�r� :";
    switch (a)
    {
        case 0:
            cout << "Benzin"<<endl;
            break;
        case 1:
            cout << "Dizel"<<endl;
            break;
        case 2:
            cout << "Lpg"<<endl;
            break;
        case 3:
            cout << "Hibrit"<<endl;
            break;
        default:
        	cout<<"Yak�t t�r�n� dogru girmediniz";
            break;
    }
    cout << "------------------------------------------------" << endl;
    cout << "------------------------------------------------" << endl;
	
	cout<<"Suv arac�n�n markas�n� giriniz :";
	cin>>suv.marka;
	cout<<"Suv arac�n�n modelini giriniz :";
    cin>>suv.model;
    cout<<"Suv arac�n�n �retim y�l�n� giriniz :";
    cin>>suv.yil;
    cout<<"Suv arac�n�n yak�t t�r�n� giriniz (Benzin=0 Dizel=1 Lpg=2 Hibrit=3) :";
    cin>>b;
    cout<<"Suv arac�n�n kilometresini giriniz :";
    cin>>suv.km;
    cout<<"Suv arac�n�n fiyat�n� giriniz :";
    cin>>suv.fiyat;
   
    cout << "------------------------------------------------" << endl;
    cout << "------------------------------------------------" << endl;

    cout << suv.marka << " " << suv.model << " Arac�n�n �zellikleri:" << endl;
    cout << "�retim tarihi : " << suv.yil << endl << "Kilometresi : " << suv.km << endl << "Yak�t t�r� :";
    switch (b)
    {
    case 0:
        cout << "Benzin" << endl;
        break;
    case 1:
        cout << "Dizel" << endl;
        break;
    case 2:
        cout << "Lpg" << endl;
        break;
    case 3:
        cout << "Hibrit" << endl;
        break;
    default:
    	cout<<"Yak�t t�r�n� dogru girmediniz";
        break;
    }
    cout << "------------------------------------------------" << endl;
    cout << "------------------------------------------------" << endl;
    
	cout<<"Ticari arac�n�n markas�n� giriniz :";
	cin>>ticari.marka;
	cout<<"Ticari arac�n�n modelini giriniz :";
    cin>>ticari.model;
    cout<<"Ticari arac�n�nc�n �retim y�l�n� giriniz :";
    cin>>ticari.yil;
    cout<<"Ticari arac�n�n yak�t t�r�n� giriniz (Benzin=0 Dizel=1 Lpg=2 Hibrit=3) :";
    cin>>c;
    cout<<"Ticari arac�n�n kilometresini giriniz :";
    cin>>ticari.km;
    cout<<"Ticari arac�n�n fiyat�n� giriniz :";
    cin>>ticari.fiyat;
   

    
   
    cout << "------------------------------------------------" << endl;
    cout << "------------------------------------------------" << endl;

    cout << ticari.marka << " " << ticari.model << " Arac�n�n �zellikleri:" << endl;
    cout << "�retim tarihi : " << ticari.yil << endl << "Kilometresi : " << ticari.km << endl << "Yak�t t�r� :";
    switch (c)
    {
    case 0:
        cout << "Benzin" << endl;
        break;
    case 1:
        cout << "Dizel" << endl;
        break;
    case 2:
        cout << "Lpg" << endl;
        break;
    case 3:
        cout << "Hibrit" << endl;
        break;
    default:
    	cout<<"Yak�t t�r�n� dogru girmediniz";
        break;
    }
    cout << "------------------------------------------------" << endl;
    cout << "------------------------------------------------" << endl;

    return 0;
}
